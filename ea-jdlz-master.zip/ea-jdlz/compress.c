/*
License unknown
Source: https://nishi.dreamhosters.com/u/jdlz_v1.rar

Edited by fierelier
*/


#ifndef EA_JDLZ_COMPRESS_C
#define EA_JDLZ_COMPRESS_C
enum {
	winlog=12,
	winsize=2048+17,
	winmask=(1<<winlog)-1
};

unsigned char win[winmask+1];


int ea_jdlz_compress( unsigned char* inp, unsigned char* out, unsigned int inpsize ) {
	unsigned int c,i,j,k,r,flag,qlag,qi,pos,l,ml,mj;

	unsigned char* inpptr;
	unsigned char* outptr;
	unsigned char* pflag; // literal/match flags (1=match)
	unsigned char* qflag; // RLE/match flags (1=run)

	for( i=0; i<winsize; i++ ) win[i]=0;

	qi=8; // reserve run flags right away

	for( pos=0,inpptr=inp,outptr=out; inpptr<inp+inpsize; ) {
		flag = 0; 
		pflag = outptr++;

		for( i=0; i<8; i++ ) {	

			if( inpptr>=inp+inpsize ) break;

			if( qi>=8 ) {
				qlag = 0; qi=0; // RLE flags
				qflag = outptr++;
			}

			k = pos-(winsize-1); if( (int)k<0 ) k=0;
			l = inp+inpsize-inpptr; if( l>2047+3 ) l=2047+3;
			ml = 0; // max match len
			mj = 0; // max match pos
			for( j=k; j<pos; j++ ) {
				for( r=0; r<l; r++ ) if( inpptr[r]!=inp[j+r] ) break;
				if( (r>31+3) && (pos-j>=17) ) r=31+3;
				if( r>=ml ) { ml=r; mj=j; }
			}

			if( ml<3 ) {
				// literal
				c = *inpptr++;
				win[ (pos++)&winmask ] = c; 
				*outptr++ = c;

			} else {
				// match

				flag |= 1<<i; // set literal flag

				if( (pos-mj)<17 ) {
					qlag |= 1<<qi++;
					// LLLLdddd
					// llllllll
					mj = (pos-mj)-1; 
					*outptr++ = (((ml-3)>>8)<<4) + mj;
					*outptr++ = (unsigned char)(ml-3);
				} else {
					qlag |= 0<<qi++;
					// DDDlllll 
					// dddddddd
					mj = (pos-mj)-17;
					*outptr++ = ((mj>>8)<<5) + (ml-3);
					*outptr++ = (unsigned char)mj;
				}

				for( j=0; j<ml; j++ ) {
					c = *inpptr++;
					win[ (pos++)&winmask ] = c; 
				}

				if( qi>=8 ) *qflag = qlag; 
			}

		} // for

		*pflag = flag;
	} *qflag = qlag; 

	return outptr-out;
}
#endif
