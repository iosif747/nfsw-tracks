#!/usr/bin/env sh
if [ "$CC" = "" ]; then
	CC=gcc
fi

$CC $CFLAGS main-decompress.c -o ea-jdlz-decompress
$CC $CFLAGS main-compress.c -o ea-jdlz-compress
