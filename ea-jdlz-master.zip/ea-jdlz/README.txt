Tool for (de)compressing EA JDLZ files. Useful for a couple of PS2-era EA titles, like the Need for Speed games.

I found myself making this, because certain people were making this part of their modding softwares proprietary.

Works for Windows 95+ (MinGW) and Unix (GCC)!

* Decompress:
ea-jdlz-decompress.exe gameplay.lzc gameplay.bin

* Compress:
ea-jdlz-compress.exe gameplay.bin gameplay.lzc

* Builds: http://fier.me/software/ea-jdlz/

* How to compile source:
For Unix, use make.sh. For Windows, use make-windows.sh (needs linux).
