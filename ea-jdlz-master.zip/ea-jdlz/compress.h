#ifndef EA_JDLZ_COMPRESS_C
#define EA_JDLZ_COMPRESS_C
int ea_jdlz_compress( unsigned char* inp, unsigned char* out, unsigned int inpsize );
#endif
