#!/usr/bin/env sh
rm ea-jdlz_windows-x86.zip
rm -rf zip
mkdir -p zip/src
cp -r . zip/src
cd zip
rm -rf src/zip
mv src/*.exe .
rm src/ea-jdlz-*
rm src/*.zip
cp src/README.txt .
zip ../ea-jdlz_windows-x86.zip -r .
cd ..

rm ea-jdlz_linux-i486.zip
rm -rf zip
mkdir -p zip/src
cp -r . zip/src
cd zip
rm -rf src/zip
rm src/ea-jdlz-*.exe
mv src/ea-jdlz-* .
rm src/*.zip
cp src/README.txt .
zip ../ea-jdlz_linux-i486.zip -r .
cd ..
