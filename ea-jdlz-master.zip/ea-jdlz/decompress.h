#ifndef EA_JDLZ_DECOMPRESS_H
#define EA_JDLZ_DECOMPRESS_H
int ea_jdlz(unsigned char *in, int insz, unsigned char *out, int outsz);
#endif
