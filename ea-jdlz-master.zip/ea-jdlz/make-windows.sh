#!/usr/bin/env sh
export PATH="/usr/lib/mingw64-toolchain/bin:$PATH"
if [ "$CC" = "" ]; then
	export CC=i686-w64-mingw32-gcc
fi

export CFLAGS="-march=i486 -O2 -D_WIN32_WINNT=0x0400 -DWINVER=0x0400 -D__USE_MINGW_ANSI_STDIO=0 $CFLAGS"

./make.sh
